<?php
session_start();

// Vérifie si l'utilisateur est connecté
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

// Récupération des infos de session
$nom = $_SESSION["user_name"];
$role = $_SESSION["role"];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bienvenue</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="form-container">
        <h2>Bienvenue, <?= htmlspecialchars($nom) ?> !</h2>
        <p>Vous êtes connecté en tant que <strong><?= htmlspecialchars($role) ?></strong>.</p>

        <?php if ($role === "candidat"): ?>
            <a href="../offres/filtrer.php"><button>Voir les offres</button></a>
        <?php elseif ($role === "entreprise"): ?>
            <a href="../offres/ajouter.php"><button>Publier une offre</button></a>
        <?php endif; ?>
    </div>
</body>
</html>
